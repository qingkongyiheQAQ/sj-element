<script setup lang="ts">
import { onMounted } from "vue";

onMounted(() => {
  console.log("🔍 ConfigProvider onMounted 触发！");
});

import type { ConfigProviderProps } from "./types";
import { provideGlobalConfig } from "./hooks";

defineOptions({
  name: "SjConfigProvider",
});
const props = defineProps<ConfigProviderProps>();
const config = provideGlobalConfig(props);
console.log("🔍 ConfigProvider 提供的 locale:", props.locale)
</script>

<template>
  <slot name="default" :config="config"></slot>
</template>
